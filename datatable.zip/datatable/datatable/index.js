//-------------------------------------------------------GET METHOD------------------------------------------------------------//
$(document).ready(function () {
    
    function loadloc() {
         var studentData = JSON.parse(localStorage.getItem('studentdata'));
         console.log(studentData);
      if (studentData != null && studentData.length > 0) {
          createTable();
       }
       else {
            $.get("student.json", function (data) {
                localStorage.setItem('studentdata', JSON.stringify(data));
                createTable();
            })
        }
   }
    loadloc() 
 
  });
 $(document).ready(function () {
    $('#mytable').DataTable();
});


//-----------------------------------------------CREATE TABLE FUNCTION---------------------------------------------------------//
function createTable() {
    var dataStudent = jQuery.parseJSON(localStorage.getItem("studentdata"));
    var headarr = ["Student Id", "Name", "Course", "Email", "Roll No"]//Object.keys(dataStudent[0]);
    let mytable = "<table id='mytable' class='table table-striped'>";
    let tabhead = "<thead>";
    let tabthrow = "<tr>";

    for (let i = 0; i < headarr.length; i++) {
      const tah = "<th>" + headarr[i] + "</th>";
      tabthrow += tah;
    }
    tabhead += tabthrow;
    tabhead += "<th>Actions</th></tr></thead>";
    mytable += tabhead;
    mytable += "<tbody>"

    for (let i = 0; i < dataStudent.length; i++) {
      mytable += "<tr><td>" + dataStudent[i].student_Id + "</td><td>" + dataStudent[i].Name + "</td><td>" + dataStudent[i].Course + "</td><td >" + dataStudent[i].Email + "</td><td>" + dataStudent[i].Roll_no + "</td><td>" + "<button type='button' data-bs-toggle='modal'data-bs-target='#exampleModal'onclick='editUser(this)'class='edit '><i class='fa-solid fa-pen-to-square'></i></button>" + "<button type='button' class='delete m-1 ' onclick='deleteUser(this)' ><i class='fa-solid fa-trash'></i></i></button>" +  "</td></tr>"
    }

    mytable += "</tbody></table>";
    $("#studentfile").append(mytable);

}
//add data to table
function AddData(){
  
  console.log("x");
  var dataStudent = JSON.parse(localStorage.getItem("studentdata"));
  console.log(dataStudent);
 var s_name=$("#studentname").val();
 console.log(s_name);
   var course=$("#Selectcourse option:selected").text();
 var mail= $("#email").val();
  var rollno=$("#rollno").val();
 var id=$("#studentid").val();
  var y=parseInt(dataStudent[dataStudent.length-1].student_Id+1);
  
  console.log(y);
   if (id==null || id==""){
    var obj={
      "student_Id":parseInt(dataStudent[dataStudent.length-1].student_Id+1),
      "Name":s_name,
      "Course":course,
      "Email":mail,
      "Roll_no":rollno
    };
    console.log(obj);
    dataStudent.push(obj);
    localStorage.setItem("studentdata",JSON.stringify(dataStudent));
    window.location.reload();
  }
   else {
   var obj={
        "student_Id":id,
        "Name":s_name,
       "Course":course,
      "Email":mail,
      "Roll_no":rollno
      };
     index=dataStudent.findIndex(x=>x.student_Id==id);
     console.log(index);
     dataStudent.splice(index,1,obj);
     localStorage.setItem("studentdata",JSON.stringify(dataStudent));
    window.location.reload();
    }
   }

   
  //edit user in table


function editUser(e) {
  console.log("HELLO");
    var dataStudent = JSON.parse(localStorage.getItem("studentdata"));
    var x = e.parentElement.parentElement.rowIndex;
    console.log(x);
     document.getElementById("studentid").value= dataStudent[x-1].student_Id;
    console.log(dataStudent[x-1].Name);
    document.getElementById("studentname").value= dataStudent[x-1].Name;
    document.getElementById("Selectcourse").value= dataStudent[x-1].Course;
    document.getElementById("email").value = dataStudent[x-1].Email;
    document.getElementById("rollno").value=dataStudent[x-1].Roll_no;
    
    

}
// Delete users

function deleteUser(e) {

  let text = "Press a button!\nAre You Sure .";   
  if (confirm(text) == true) 
  { 
  var data = JSON.parse(localStorage.getItem("studentdata"));
  var x = e.parentElement.parentElement.rowIndex;
  data.splice((x - 1), 1);
  localStorage.setItem("studentdata", JSON.stringify(data));    
   window.location.reload();
    } 
    else {
      window.location.reload();
    }
  }





  



// jquery validator--------------------------------------->

  // $("#basic-form").validate({
   
  //   rules: {
      
  //     studentname: { required:true},
  //     Selectcourse: {required:true},
  //    email: {
  //       required: true,
       
  //       email: true
  //     },
  //     rollno: {
  //       required: true
        
  //     }
  //   },
  //   messages: {
  //     studentname: {required:"Please enter student name"},
  //     Selectcourse: {required:"Please select your course"},
  //     rollno: {
  //       required: "Please provide a roll number"
        
  //     },
  //     email:{ required:"Please enter a valid email address"
  //   }
  // }

  // });


  